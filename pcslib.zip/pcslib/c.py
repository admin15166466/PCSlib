from time import *
from cpslib import _raise_CPSerror_object


def clean(t):
    import sys
    try:
        t = int(t)
        sleep(t)
    except ValueError:
        _raise_huoyanerror_object()
    sys.stdout.write('\033[2J\033[00H')


def clear():
    import sys
    sys.stdout.write('\033[2J\033[00H')

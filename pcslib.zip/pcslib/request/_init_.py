class CpsLibRequestsError(Exception):
	"""Nothing"""

def _raise_cpslibrequestserror_sys():
	raise CpsLibRequestsError(
		'length of object \'sys.argv\' is not enough,please use 360 explorer -- xueersi running this function'
	)


def _raise_cpslibrequestserror_socket():
	raise class CpsLibRequestsError('can\'t connekt to socket server.')